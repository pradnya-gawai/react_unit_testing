import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import "./App.css";
import Home from "./pages/Home";
import Contact from "./pages/Contact";
import Header from "./components/Header"

const App = () => {
  return (
    // <div style={{ backgroundColor: "#fff" }}>
    //   <Routes>
    //     <Route path="/" element={<Home />} />
    //     <Route path="/sampletest" element={<Contact />} />
    //   </Routes>
    // </div>
    <>
    <Header/>
    <div style={{ backgroundColor: "#fff" }}>
     <Routes>
        <Route path="/" element={<Home />} />
         <Route path="/sampletest" element={<Contact />} />
       </Routes>
     </div>

    </>
  );
};

export default App;
